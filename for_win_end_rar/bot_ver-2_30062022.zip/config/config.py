MAIN_URL = 'https://agregatoreat.ru/'
LOGIN_URL = 'https://agregatoreat.ru/lk/supplier'
TRADES_URL = 'https://agregatoreat.ru/purchases/new'
