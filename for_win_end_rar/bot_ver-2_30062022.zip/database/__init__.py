from .controller import Controller


Controller = Controller()
