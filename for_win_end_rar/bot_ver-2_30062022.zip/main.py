from bot import Bot


if __name__ == '__main__':
    mail = input('Введите логин аккаунта: ')
    password = input('Введите пароль аккаунта: ')
    certificate_name = input('Введите название сертификата: ')
    tin = input('Введите ИНН для поиска: ')
    keyword = input('Введите ключевую фразу или нажмите Enter для выбора всех процедур: ')
    first_desc = input('Введите название ТРУ: ')
    second_desc = input('Введите описание ТРУ: ')
    bets_to_exclude = input('Введите номера ставок для исключения через пробел: ').split()

    bot = Bot(mail=mail, password=password, certificate_name=certificate_name, tin=tin,
              keyword=keyword, first_desc=first_desc, second_desc=second_desc, bets_to_exclude=bets_to_exclude)

    bot.login()
    bot.make_bet()

    input()
